		</div>
		<!-- /page content -->

	</div>
	<!-- /page container -->
    
    
    <!-- Footer -->
	<div class="footer text-muted">
		&copy; <?= date('Y') ?>. <a href="#">Travel CRS</a> | <a href="http://www.pilihberita.com" target="_blank">Supported By : pilihberita.com</a>
	</div>
	<!-- /footer -->

	<!-- Core JS files -->
	<script type="text/javascript" src="assets/backend/js/plugins/loaders/pace.min.js"></script>
	<script type="text/javascript" src="assets/backend/js/core/libraries/jquery.min.js"></script>
	<script type="text/javascript" src="assets/backend/js/core/libraries/bootstrap.min.js"></script>
	<script type="text/javascript" src="assets/backend/js/plugins/loaders/blockui.min.js"></script>
	<!-- /core JS files -->

	<!-- Theme JS files -->	
	<script type="text/javascript" src="assets/backend/js/plugins/tables/datatables/datatables.min.js"></script>
	<!--<script type="text/javascript" src="assets/backend/js/plugins/forms/select2-4.0.3/dist/js/select2.min.js"></script>-->
    <script type="text/javascript" src="assets/backend/js/plugins/forms/selects/select2.min.js"></script>
	<script type="text/javascript" src="assets/backend/js/plugins/forms/validation/validate.min.js"></script>

	<script type="text/javascript" src="assets/backend/js/core/app.js"></script>
	<script type="text/javascript" src="assets/backend/js/core/setting.js"></script>

	<script type="text/javascript" src="assets/backend/js/plugins/ui/ripple.min.js"></script>
	<!-- /theme JS files -->