<li class="menu-item <?= y_menu_class($mode); ?>">
    <a href="<?= base_url() ?>">Home</a>
</li>
<li class="menu-item <?= y_menu_class($mode); ?>">
    <a href="<?= base_url() ?>places">Destinasi Wisata</a>
</li>
<li class="menu-item <?= y_menu_class($mode); ?>">
    <a href="<?= base_url() ?>recommender">Rekomendasi Jadwal Wisata</a>
</li>