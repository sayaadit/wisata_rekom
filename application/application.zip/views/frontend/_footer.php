<div class="td-footer-wrapper td-container-wrap" style="background-color:#0C47A1; padding-top:0px">    
    <div class=td-footer-bottom-full><div class=td-container><div class=td-pb-row>
        <div class=td-pb-span3>
        	<aside class=footer-text-wrap>
            	<div class=block-title><span>&nbsp;</span></div>
            	<a href="https://demo.tagdiv.com/newspaper/">
                	<img class=td-retina-data src="assets/frontend/images/travel-crs.png" data-retina="assets/frontend/images/travel-crs-retina.png" alt="" title="CRS Travel"/>
                </a>
           	</aside>
        </div>
        <div class=td-pb-span5>
        	<aside class=footer-text-wrap>
            	<div class=block-title><span>TRAVEL CRS</span></div>
                Travelling Conversation Recommender System (Travel-CRS) adalah ...
            </aside>
        </div>
        <div class=td-pb-span4>
        	<aside class="footer-social-wrap td-social-style-2">
            	<div class=block-title><span>FOLLOW US</span></div>
                <span class="td-social-icon-wrap">
                    <a target="_blank" href="https://www.facebook.com/soc.telkomuniversity/" title="Facebook"><i class="td-icon-font td-icon-facebook"></i></a>
                </span>
                <span class="td-social-icon-wrap">
                    <a target="_blank" href="https://www.facebook.com/groups/soc.telkomuniversity/" title="Facebook"><i class="td-icon-font td-icon-facebook"></i></a>
                </span>
                <span class="td-social-icon-wrap">
                    <a target="_blank" href="https://www.youtube.com/user/soctelkomuniv" title="Youtube"><i class="td-icon-font td-icon-youtube"></i></a>
                </span>
        	</aside>
    	</div> 
    </div></div></div>
</div>
    
<!-- Footer Bottom -->
<div class="td-sub-footer-container td-container-wrap" style="background-color:#0A3D8B; color:#ffffff">
    <div class=td-container>
        <div class=td-pb-row>
            <div class="td-pb-span td-sub-footer-menu">
                <div class=menu-footer-menu-container>
                    <ul id=menu-footer-menu class=td-subfooter-menu>
                    	<li id=menu-item-16 class="menu-item menu-item-first td-menu-item td-normal-menu"><a href="http://www.pilihberita.com" target="_blank">Supported By : pilihberita.com</a></li>
                    </ul>
                </div> 
            </div>
            <div class="td-pb-span td-sub-footer-copy">&copy; Copyright <?= date('Y') ?> - Travel CRS</div>
        </div>
    </div>
</div>
    <!-- End Footer Bottom -->