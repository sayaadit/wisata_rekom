<?php $this->load->view('backend/tpl_footer'); ?>
