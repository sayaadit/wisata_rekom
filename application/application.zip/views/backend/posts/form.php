<style>
.navigation-custom > li > a {
	padding: 1px 20px;
    min-height: 0px;
}
.media-imgs {
	width:125px; 
	height:95px; 
	padding-right:10px; 
	padding-left:0px; 
	margin-bottom:5px; 
	padding-bottom:0px; 
	overflow:hidden;
}
.media-imgs > .active {
	background-color:#F44336 !important;
}
.media-imgs > .thumbnail {
	margin-bottom:5px;
	cursor:pointer;
}
.media-imgs .thumb {
	height:87px; 
	overflow:hidden; 
	background-color:#fff;
}
.media-imgs .thumb-sign {
	position:absolute;
	right:0px;
}

.media-left-container {
	width:81px;
	height:70px;
	overflow:hidden;
	background-color:#f2f2f2;
	border:solid 2px #aaa;
	border-radius:5px;
}

.media-left-container > img {
	width:81px !important;
	height:auto !important;
}

.bootstrap-tagsinput {
	border-bottom:solid 1px #ddd;
	padding-bottom:10px;
}

.map-input {
	position:absolute;
	height: 30px;
	padding: 4px 8px;
	background-color:#ffff8d;
	z-index:1000000;
	border:solid 1px #ef6c00;
	width:35%;
}

.dataTables_filter, .dataTables_length { display:none }
</style>
<?php if(isset($error) && $error) { ?>
<div class="alert alert-warning alert-styled-left">
    <span class="text-semibold">Warning!</span><br>Data post artikel tidak ditemukan. Mungkin terjadi kesalahan atau sudah dihapus.
</div>
<?php } ?>
                        
<form action="<?= $action ?>" method="post" enctype="multipart/form-data">
<?php if($edit) { ?>
<input type="hidden" name="id" id="id" value="<?= $data->post_id ?>">
<?php } ?>
<!-- Detached content -->
<div class="container-detached">
    <div class="content-detached">
		
        <div class="panel panel-default flat border-top-xlg border-success">
            <div class="panel-body">
                <div class="form-group">
                    <label>Judul</label>
                    <input type="text" name="inp[post_title_id]" id="post_title_id" class="form-control" value="<?= $edit ? $data->post_title_id : '' ?>">
                </div>

                <div class="form-group">
                    <div class="row">
                        <div class="col-md-6">
                            <label>Konten</label>
                        </div>
                        <div class="col-md-6" style="text-align:right">
                            <button type="button" id="insert_media" onClick="ins_media('ins_post')" class="btn btn-primary btn-labeled btn-xs" style="margin-bottom:10px">
                                <b><i class="icon-media"></i></b> Insert Media
                            </button>
                        </div>
                    </div>                       
                    
                    <textarea name="inp[post_content_id]" id="post_content_id" rows="4" cols="4"><?= $edit ? $data->post_content_id : '' ?></textarea>
                </div>
                
                <div class="form-group">
                    <label>Konten Singkat (Preview)</label>
                    <textarea name="inp[post_excerpt_id]" id="post_excerpt_id" class="form-control" rows="4" cols="4"><?= $edit ? $data->post_excerpt_id : '' ?></textarea>
                </div>
                
                <div class="form-group">
                    <label class="display-block">Gambar Cover:</label>
                    <div class="media no-margin-top">
                        <div class="media-left">
                            <div class="media-left-container" id="ins-cover-img">
                            <?= $edit ? '<img src="'.$data->post_img.'">' : '' ?>
                            </div>
                        </div>

                        <div class="media-body">
                            <button type="button" class="btn btn-xs btn-labeled bg-pink" onClick="ins_media('ins_cover')">
                            	<b><i class="icon-media"></i></b> Pilih Gambar Cover
                            </button>
                            <span class="help-block" id="ins-cover-name">Silahkan piilih gambar untuk cover (untuk ukuran terbaik 1300px X 1125px)</span>
                            <input type="hidden" name="inp[post_img]" id="ins-cover-input" value="<?= $edit ? $data->post_img : '' ?>">
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- maps -->
        <div class="panel panel-white">
            <div class="panel-heading">
                <h5 class="panel-title">Lokasi / Alamat <small>(Anda dapat mengubah lokasi dengan memindahkan ikon warna merah (marker))</small></h5>
                <div class="heading-elements">
                    <ul class="icons-list">
                        <li><a data-action="collapse"></a></li>
                    </ul>
                </div>
            </div>

            <div class="panel-body">
                <div class="row">
                    <div class="col-md-12">
                        <div class="form-group">
                            <label>Alamat :</label>
                            <input name="inp[post_address]" id="post_address" class="form-control" placeholder="Masukkan alamat" value="<?= $edit ? $data->post_address : '' ?>">
                        </div>
                    </div>
                </div>

                <div class="form-group">
                	<input name="search_address" id="search_address" class="map-input" placeholder="Pencarian berdasarkan alamat dan tekan enter untuk mencari">
                    <div id="map2" class="map-wrapper content-group-sm"></div>
                </div>
                
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label>Latitude:</label>
                            <input type="text" name="inp[post_lat]" id="post_lat" class="form-control" value="<?= $edit && !empty($data->post_lat) ? $data->post_lat : '' ?>">
                        </div>
                    </div>
                    
                    <div class="col-md-6">
                        <div class="form-group">
                            <label>Longitude:</label>
                            <input type="text" name="inp[post_long]" id="post_long" class="form-control" value="<?= $edit && !empty($data->post_long) ? $data->post_long : '' ?>">
                        </div>

                    </div>
                </div>
            </div>
        </div>
        <!-- end maps -->
        
        <!-- time matrix -->
        <div class="panel panel-white">
            <div class="panel-heading">
                <h5 class="panel-title">Time Matrix</h5>
                <div class="heading-elements">
                    <ul class="icons-list">
                        <li><a data-action="collapse"></a></li>
                    </ul>
                </div>
            </div>

            <div class="panel-body">
                <table class="table table-bordered table-striped table-hover" id="table">
                    <thead>
                        <tr>
                            <th width="30%">Dari</th>
                            <th width="30%">Menuju</th>
                            <th width="10%">Hari</th>
                            <th width="10%">Waktu Tempuh</th>
                            <th width="20%">&nbsp;</th>
                        </tr>
                    </thead>
                    <tbody></tbody>
                </table>
            </div>
        </div>
        <!-- end time matrix -->
        
        <!-- video -->
        <div class="panel panel-white">
            <div class="panel-heading">
                <h5 class="panel-title">SEO (Search Engine Optimization)</h5>
                <div class="heading-elements">
                    <ul class="icons-list">
                        <li><a data-action="collapse"></a></li>
                    </ul>
                </div>
            </div>

            <div class="panel-body">
                <div class="form-group">
                    <label>Judul SEO</label>
                    <input type="text" name="inp[post_seo_title]" id="post_seo_title" class="form-control" value="<?= $edit ? $data->post_seo_title : '' ?>">
                </div>
                <div class="form-group">
                    <label>Deskripsi SEO (Maksimal 160 karakter)</label>
                    <input type="text" name="inp[post_seo_desc]" id="post_seo_desc" class="form-control" value="<?= $edit ? $data->post_seo_desc : '' ?>">
                </div>
                <div class="form-group">
                    <label>Keywoord (Kata Kunci) SEO (Pisahkan dengan <strong>koma (,)</strong> antar keywoord)</label>
                    <input type="text" name="inp[post_seo_keyword]" id="post_seo_keyword" class="form-control" value="<?= $edit ? $data->post_seo_keyword : '' ?>">
                </div>
            </div>
        </div>
        <!-- end video -->
    </div>
</div>

<!-- Detached sidebar -->
<div class="sidebar-detached">
    <div class="sidebar sidebar-default">
        <div class="sidebar-content">
            <!-- Action buttons -->
            <div class="sidebar-category">
                <div class="category-content no-padding">
                    <ul class="navigation navigation-alt navigation-custom navigation-accordion" style="padding-bottom:0px">
                        <li>
                            <a href="javascript:;"><i class="icon-calendar2"></i> <?= $edit ? date('d/m/Y H:i', strtotime($data->post_date)) : date('d/m/Y H:i') ?></a>
                        </li>
                        <li>
                            <a href="javascript:;"><i class="icon-file-check"></i> <?= $edit ? ($data->post_status == 1 ? 'Publish' : 'Non Aktif') : 'Non Aktif' ?></a>
                        </li>
                    </ul>
                </div>
                
                <div class="category-content">
                    <div class="row">
                        <div class="col-xs-6">
                            <button type="submit" class="btn bg-success btn-block btn-float btn-float-lg">
                                <i class="icon-floppy-disk"></i> <span><?= $edit ? 'Update' : 'Publish' ?></span>
                            </button>
                        </div>
                        
                        <div class="col-xs-6">
                            <a href="<?= y_url_admin() ?>/posts" class="btn bg-pink btn-block btn-float btn-float-lg"><i class="icon-switch"></i> <span>Batal</span></a>
                        </div>
                    </div>
                </div>
            </div>
            <!-- /action buttons -->
            <!-- Action buttons -->
            <div class="sidebar-category">
                <div class="category-title">
                    <span>Kategori</span>
                    <ul class="icons-list">
                        <li><a href="#" data-action="collapse"></a></li>
                    </ul>
                </div>
    
                <div class="category-content"><form action="#">
                    <div class="form-group">
                        <label>Tipe Post :</label>
                        <?= form_dropdown('inp[post_type]', $type, $edit ? $data->post_type : '', 'class="form-control bg-teal input-xs" id="post_type" required'); ?>
                    </div>
                    
                    <div class="form-group">
                        <label>Kategori :</label>
                        <div id="cat-container">
                        <?php foreach($cats as $c) { ?>
                        <div class="checkbox">
                        	<label><input type="checkbox" name="cats[]" value="<?= $c->cat_id ?>" class="control-success chk"><?= $c->cat_name ?></label>
                        </div>
                        <?php } ?>
                        </div>
                    </div>
                </form></div>
            </div>
            <!-- /action buttons -->
        </div>
    </div>
</div>

</form> 

<div class="modal fade" id="frmbox" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-full">
        <div class="modal-content">
            <div class="modal-header bg-teal">
            	<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            	<h4 class="modal-title"><i class="fa fa-navicon"></i> &nbsp;<?= 'Form '.$title ?></h4>
            </div>
            <div class="modal-body" style="padding:5px">
                <div class="row" style="margin:0px">
                	<div class="col-md-8" style="height:450px; overflow-y:scroll; background-color:#EEEDED;" id="yscroll-element">
                    	<div class="box-body" style="padding:10px">
                            <div class="row" id="media-container"></div>
                        </div>
                    </div>
                    <div class="col-md-4">
                    	<div class="row">
                        	<div class="col-md-6">
                            	<div style="background-color:#f2f2f2; height:135px; width:180px; overflow:hidden">
                            		<img id="ins-img" width="100%">
                                </div>
                            </div>
                        	<div class="col-md-6">
                            	<div id="ins-filename" style="word-wrap:break-word; max-height:60px; overflow:hidden">Pilih salah satu gambar</div>
                                <br>
                                <div style="color:#009688"><i class="icon-calendar2"></i> &nbsp;<span id="ins-date">-</span></div>
                                <div style="color:#009688"><i class="icon-file-empty"></i> &nbsp;<span id="ins-type">-</span></div>
                                <div style="color:#009688"><i class="icon-width"></i> &nbsp;<span id="ins-res">-</span></div>
                            </div>
                        </div>
                            	
                    
                    	<form id="frm" class="form-horizontal">
                        	<div class="form-group form-group-sm">
                                <label for="pus_name" class="col-sm-3 control-label">Title</label>
                                <div class="col-sm-9">
                                    <input type="text" class="form-control input-sm" name="ins-title" id="ins-title">
                                </div>
                            </div>
                            <div class="form-group form-group-sm">
                                <label for="pus_name" class="col-sm-3 control-label">Caption</label>
                                <div class="col-sm-9">
                                    <input type="text" class="form-control input-sm" name="ins-caption" id="ins-caption">
                                </div>
                            </div>
                            <div class="form-group form-group-sm">
                                <label for="pus_name" class="col-sm-3 control-label">Alignment</label>
                                <div class="col-sm-9">
                                    <select class="form-control input-sm" name="ins-align" id="ins-align">
                                    	<option value="left">Left</option>
                                    	<option value="center">Center</option>
                                    	<option value="right">Right</option>
                                    </select>
                                </div>
                            </div>
                            <div class="form-group form-group-sm">
                                <label for="pus_name" class="col-sm-3 control-label">Size</label>
                                <div class="col-sm-9">
                                    <select class="form-control input-sm" name="ins-size" id="ins-size">
                                    	<?php $sizes = $this->config->item('thumb'); foreach($sizes as $stitle => $size) { ?>
                                    	<option value="<?= $size['name'] ?>"><?= ucwords($stitle).' - '.$size['name'] ?></option>
                                        <?php } ?>
                                    </select>
                                </div>
                            </div>                            
                            <div class="form-group form-group-sm" style="text-align:center; padding-top:5px">
                            	<button type="button" class="btn btn-danger btn-labeled btn-xs" data-dismiss="modal">
                                    <b><i class="icon-switch"></i></b> Close
                                </button> &nbsp;                 
                                <button type="button" class="btn btn-success btn-labeled btn-xs" id="ins-button">
                                    <b><i class="icon-floppy-disk"></i></b> Insert into post
                                </button>
                            </div>
                        </form>   
                    
                    </div>
                </div>
            </div>
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div><!-- /.modal -->


<?php $this->load->view('backend/tpl_footer'); ?>
<script type="text/javascript" src="assets/backend/js/plugins/forms/tags/tagsinput.min.js"></script>
<script type="text/javascript" src="assets/backend/js/plugins/forms/tags/tokenfield.min.js"></script>

<script type="text/javascript" src="assets/backend/js/plugins/editors/ckeditor/full/ckeditor.js"></script>
<script type="text/javascript" src="assets/backend/js/plugins/forms/styling/uniform.min.js"></script>

<!--map picker-->
<script type="text/javascript" src="http://maps.google.com/maps/api/js?key=AIzaSyAPQXi7ZBZ73SPXi7JfHycSCi30thvQGCg&amp;sensor=false&amp;libraries=places"></script>

<script type="text/javascript" src="assets/backend/js/core/libraries/jquery_ui/widgets.min.js"></script>
<script type="text/javascript" src="assets/backend/js/plugins/forms/inputs/typeahead/typeahead.bundle.min.js"></script>
<script type="text/javascript" src="assets/backend/js/plugins/pickers/location/typeahead_addresspicker.js"></script>
<script type="text/javascript" src="assets/backend/js/plugins/pickers/location/autocomplete_addresspicker.js"></script>
<script type="text/javascript" src="assets/backend/js/plugins/pickers/location/location.js"></script>
<script type="text/javascript" src="assets/backend/js/plugins/ui/prism.min.js"></script>
<script type="text/javascript" src="assets/backend/js/plugins/jscroll/jquery.jscroll.min.js"></script>

<script>
var tb 		= '#table';      
var baseurl = '<?= y_url_admin() ?>/posts';
var form1   = $('#frm');
var validator = form1.validate();
var dt;

//ins
var ins_page = 0;
var ins_show = false;
var ins_full = false;

$(document).ready(function() {	
	CKEDITOR.addCss( 'body {font-family: Roboto, Arial, Verdana; font-size: 13px; color:#333}' );
	CKEDITOR.replace( 'post_content_id', {
        height: '400px',
		fullPage: true,
		allowedContent: true,
		toolbar : 'MyToolbar'
    });
	
	// File input
    $(".file-styled").uniform({
        fileButtonClass: 'action btn bg-pink-400'
    });
	
	$(".control-success").uniform({
        radioClass: 'choice',
        wrapperClass: 'border-success-600 text-success-800'
    });
	
	// Address Picker 
	//Initialization
    var addresspickerMap = $("#search_address").addresspicker({
        regionBias: "fr",
        updateCallback: showCallback,
        mapOptions: {
            zoom: 14,
			
			<?php if($edit && !empty($data->post_lat) && !empty($data->post_long) ) { ?>
            center: new google.maps.LatLng(<?= $data->post_lat ?>, <?= $data->post_long ?>),
            <?php } else { ?>
            center: new google.maps.LatLng(-7.190134, 107.889733),
            <?php } ?>
			
			scrollwheel: false,
			mapTypeControl: false,
            mapTypeId: google.maps.MapTypeId.ROADMAP
        },
        elements: {
            map:      "#map2"
        }
    });

    // Add markers
    var gmarker = addresspickerMap.addresspicker("marker");
    gmarker.setVisible(true);
    addresspickerMap.addresspicker("updatePosition");

    // Reverse Geocode after Marker Drag	
	$("#search_address").addresspicker("option", "reverseGeocode", true);

    // Callback
    function showCallback(geocodeResult, parsedGeocodeResult){
        var res = parsedGeocodeResult;
		//$('#response2 code').text(JSON.stringify(parsedGeocodeResult, null, 4));
		$('#post_lat').val(res.lat);
		$('#post_long').val(res.lng);
		
        //Prism.highlightAll();
    }

    // Update zoom field
    var map = $("#search_address").addresspicker("map");
    google.maps.event.addListener(map, 'idle', function(){
        $('#zoom').val(map.getZoom());
    });
	
	$('#post_type').change(function() {
		if($(this).val() !== '') get_cat($(this).val(), []);
	});
	
	<?php if($edit) { ?>
	
	//edit
	<?php $ct = ''; if(!empty($cat)) { foreach($cat as $c) { $ct .= $c->pc_id_cat.','; } $ct = substr($ct, 0, -1); } ?>
	get_cat('<?= $data->post_type ?>', [<?= $ct ?>]);
	
	$(tb).dataTable({
        'ajax': {
            'url':baseurl+'/json_time_matrix/<?= $id ?>'
		},
		'columnDefs': [ 
			{ 'targets': [0,1,2,3], 'searchable': false, 'orderable': false } 
		],
		'drawCallback': function(setting) {
			var api = this.api();
			var js = api.rows().data();			
			var html = '';
			$.each(js, function(key, value) {
				html += '<option value="'+value[2]+'">'+value[0]+'</option>';
			});
			$('#csubstitute').html(html);
		}
    });
	
	<?php } ?>
	
	$('#frmbox').on('click', '.ins-media-click', function() {
		ins_detail($(this));
	});
});

function get_tags(q)
{
	var r = [];
	
	$.ajax({
		url:baseurl+'/get_tags',
		global:false,
		async:false,
		dataType:'json',
		type:'post',
		data: ({ q : q }),
		success: function(e) {
			r = e;
		},
		error : function() {
			alert('<?= $this->config->item('alert_error') ?>');	 
		}
	});
	
	return r;
}

function get_cat(post, check)
{
	if(post == 'location')
	{
		$('#cat-container').show();
			
		$.each(check, function(key, value) {
			$(':checkbox[value='+value+']').prop('checked', true);
		});	
	}
	else
	{
		$(':checkbox').prop('checked', false);
		$('#cat-container').hide();
	}
	
	$(".control-success").uniform({
		radioClass: 'choice',
		wrapperClass: 'border-teal-600 text-teal-800'
	});
}

function ins_media(func)
{
	$('#media-container').html('');
	//if(!ins_show)
	//{
		ins_media_load(1);
		//ins_show = true;
		ins_page = 1;
	//}
	
	$('#yscroll-element').scroll(function() {
		if(($(this).scrollTop()+$(this).innerHeight() >= $(this)[0].scrollHeight) && !ins_full)
		{
			ins_page++;
			ins_media_load(ins_page);
		}
	});
	
	$('#frmbox').off('click', '#ins-button');
	$('#frmbox').on('click', '#ins-button', function() {
		//$(this).unbind('click');
		window[func]();
	});
	
	$('#frmbox').modal({keyboard: false, backdrop: 'static'});
}

function ins_media_load(page)
{
	$.ajax({
		url:'<?= y_url_admin() ?>/media/load_json',
		global:false,
		async:false,
		dataType:'json',
		type:'post',
		data: ({ page : page }),
		success: function(e) {
			if(!e.empty)
			{
				var html = '';
				$.each(e.data, function(key, value) {
					html += '<div class="col-lg-3 col-sm-3 col-xs-3 media-imgs"><div class="thumbnail" id="thumb-'+value.id+'"><div class="thumb"><div class="thumb-sign" style="display:none" id="thumb-sign-'+value.id+'"><button class="btn btn-danger btn-xs btn-icon btn-rounded"><i class="icon-checkmark4"></i></button></div><img src="'+value.img+'" class="ins-media-click" data-img="'+value.img+'" data-filename="'+value.name+'" data-url="'+value.url+'" data-date="'+value.date+'" data-type="'+value.type+'" data-ext="'+value.ext+'" data-path="'+value.path+'" data-resolution="'+value.res+'" data-size="'+value.size+'" data-id="'+value.id+'"></div></div></div>';
				});
				
				$('#media-container').append(html);
			}
			else
			{
				ins_full = true;
			}
		},
		error : function() {
			alert('<?= $this->config->item('alert_error') ?>');	 
		},
		beforeSend : function() {
			//$('#loading-img').show();
		},
		complete : function() {
			//$('#loading-img').hide();
		}
	});
}

function ins_detail(items)
{
	$('div#ins-filename').html(items.data('filename'));
	$('span#ins-date').html(items.data('date'));
	$('span#ins-type').html(items.data('type')+' (.'+items.data('ext')+')');
	$('span#ins-res').html(items.data('size')+' ('+items.data('resolution')+')');
	$('#ins-img').attr('src', items.data('img'));
	
	var id = items.data('id');
	$('.thumbnail').removeClass('active');
	$('#thumb-'+id).addClass('active');
	$('.thumb-sign').hide();
	$('#thumb-sign-'+id).show();
	
	//$('#frmboxdetail').modal({keyboard: false, backdrop: 'static'});	
}

function ins_post()
{
	if($('#media-container div.active').length > 0)
	{
		var active = $('#media-container div.active img');
		var title = $('#ins-title').val();
		var caption = $('#ins-caption').val();
		var align = $('#ins-align').val();
		var size = $('#ins-size').val();
		var filename = active.data('path')+active.data('url')+(size != '' ? '-'+size : '')+'.'+active.data('ext');
		
		var img = '<img src="'+filename+'" title="'+title+'" alt="'+title+'" class="'+align+'"><caption>'+caption+'</caption>';
		
		CKEDITOR.instances.post_content_id.insertHtml(img);	
			
	}
}

function ins_cover()
{
	if($('#media-container div.active').length > 0)
	{
		var active = $('#media-container div.active img');
		var title = $('#ins-title').val();
		var caption = $('#ins-caption').val();
		var align = $('#ins-align').val();
		var size = $('#ins-size').val();
		var filename = active.data('path')+active.data('url')+'.'+active.data('ext');
		
		var img = '<img src="'+active.data('img')+'" title="'+title+'" alt="'+title+'">';
		
		$('#ins-cover-img').html(img);
		$('#ins-cover-name').html(active.data('filename'));
		$('#ins-cover-input').val(filename);
	}
}
</script>