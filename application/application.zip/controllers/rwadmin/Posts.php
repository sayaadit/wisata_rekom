<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Posts extends CI_Controller 
{
	function __construct()
	{
		parent::__construct();
		
		$this->load->model('Posts_Model', 'dm', TRUE);
		$this->load->model('Common_Model', 'cm', TRUE);
		$this->load->model('Ms_Category_Model', '', TRUE);
		$this->load->model('Ms_Tags_Model', '', TRUE);
		
		if (!$this->session->userdata('login')) redirect(y_url_admin().'/login');		
	}
	
	public function index()
	{
		$data['view'] 	= 'backend/posts/index';
		$data['title']	= 'Post Artikel';		
		$data['icon']	= 'icon-file-xml';	
		$data['add']	= true;
		
		$this->load->view('backend/tpl', $data);
	}
	
	public function form($id='')
	{
		$data['view'] 	= 'backend/posts/form';
		$data['title']	= 'Post Artikel';		
		$data['icon']	= 'icon-file-xml';
		$data['body']	= 'sidebar-xs has-detached-right';
		
		$this->load->helper('form');
		
		$data['type'] = $this->cm->form_post();
		$data['cats'] = $this->Ms_Category_Model->getall()->result();
		
		if(empty($id))
		{
			$data['action']	= y_url_admin().'/posts/insert';
			$data['edit']	= false;
		}
		else
		{
			$dbs = $this->dm->getbyid($id)->row();
			
			if(!empty($dbs))
			{
				$data['action']	= y_url_admin().'/posts/update';
				$data['edit']	= true;
				$data['data']	= $dbs;
				$data['cat']	= $this->dm->get_cats($id)->result();
				$data['id']		= $id;
			}
			else
			{
				$data['action']	= y_url_admin().'/posts/insert';
				$data['edit']	= false;
				$data['error']	= true;	
			}
		}
				
		$this->load->view('backend/tpl', $data);
	}
	
	public function json()
	{
		if(!$this->input->is_ajax_request()) return false;
		
		$columns = array(
			array( 'db' => 'post_date', 'dt' => 0 ),
			array( 'db' => 'post_title_id', 'dt' => 1 ),
			array( 'db' => 'post_type', 'dt' => 2 ),
			array( 'db' => 'post_status', 'dt' => 3 )
		);
		
		$this->datatables->set_cols($columns);
		$param	= $this->datatables->query();
		
		if(empty($param['where']))
			$param['where'] = " WHERE post_type != 'gallery' ";
		else
			$param['where'] .= " AND post_type != 'gallery' ";
		
		$result = $this->dm->dtquery($param)->result();
		$filter = $this->dm->dtfiltered();
		$total	= $this->dm->dtcount();
		$output = $this->datatables->output($total, $filter);
		
		foreach($result as $row)
		{
			$rows = array (
				date('Y/m/d H:i', strtotime($row->post_date)).'<br><span class="text-grey-300"><em><i class="fa fa-edit"></i> '.date('Y/m/d H:i', strtotime($row->post_modified)).'</em></span>',
				$row->post_title_id,
				$row->post_type,
				$row->post_status == 1 ? 'Publish' : 'Unpublish',
				'<a href="'.y_url_admin().'/posts/form/'.$row->post_id.'" title="Edit Data"><span class="label label-primary label-table"><i class="fa fa-edit"></i> Edit</span></a> 
				<a href="javascript:del('.$row->post_id.')" title="Hapus Data"><span class="label label-danger label-table"><i class="fa fa-trash"></i> Hapus</span></a>'
			);
			
			$output['data'][] = $rows;
		}
		
		echo json_encode( $output );
	}
	
	public function insert()
	{
		if(!$this->input->post('inp')) return false;
		
		$item = $this->input->post('inp');
		$item['post_modified'] 	= date('Y-m-d H:i:s');
		$item['post_date'] 		= date('Y-m-d H:i:s');
		$item['post_url'] 		= y_urlf($item['post_title_id']);
		$item['post_author'] 	= y_item_login('user_id');
		$item['post_status'] 	= '1';
		
		$check_url = $this->dm->getby(array('post_url' => $item['post_url']))->result();
		if(count($check_url) > 0)
			$item['post_url'] .= '-'.count($check_url)+1;				
		
		$id = $this->dm->add($item);
		
		$cats = $this->input->post('cats');
		$this->cats_handler($id, $cats);
		
		$tags = $this->input->post('tags');
		$this->tags_handler($id, $tags);	
		
		redirect(y_url_admin().'/posts/form/'.$id);
	}
	
	public function update()
	{
		if(!$this->input->post('inp')) return false;
		if(!$this->input->post('id')) return false;
		
		$item = $this->input->post('inp');
		$id   = $this->input->post('id');
		$item['post_modified'] 	= date('Y-m-d H:i:s');
		$item['post_url'] 		= y_urlf($item['post_title_id']);
		$item['post_author'] 	= '1';
		
		$check_url = $this->dm->getby(array('post_url' => $item['post_url']))->result();
		if(count($check_url) > 0)
			$item['post_url'] .= '-'.count($check_url);
		
		$cats = $this->input->post('cats');
		$this->cats_handler($id, $cats);
		
		$tags = $this->input->post('tags');
		$this->tags_handler($id, $tags);	
		
		$this->dm->edit($id, $item);
		
		redirect(y_url_admin().'/posts/form/'.$id);
	}
	
	public function publish()
	{
		if(!$this->input->is_ajax_request()) return false;
		if(!$this->input->post('id')) return false;
		
		$id = $this->input->post('id');
		$status = $this->input->post('status');
		
		$this->dm->edit($id, array('post_status' => $status));
		
		echo 'ok;';
	}
	
	public function delete()
	{
		if(!$this->input->is_ajax_request()) return false;
		if(!$this->input->post('id')) return false;
		
		$id = $this->input->post('id');
		$db = $this->dm->getbyid($id)->row();
		
		$this->dm->delete($id);
		$this->dm->delete_cat($id);
		$this->dm->delete_timematrix($id);
		$this->dm->delete_hotel_timematrix($id);
		
		echo 'ok;';
	}
	
	/**		FOR ADDITONAL FUNCTION
			Untuk Menambah function baru silahkan letakkan di bawah ini.
	**/
	
	private function tags_handler($id_post, $tags_txt)
	{
		$tags = explode(',', $tags_txt);
		
		//get exsisting ms_tags in database
		$tags_txt_in = '';
		foreach($tags as $tag)
			$tags_txt_in .= "'$tag',";
		$tags_txt_in = substr($tags_txt_in,0,-1);
		
		$tags_db = $this->Ms_Tags_Model->getbytags($tags_txt_in)->result();
		$tags_db_array = array();
		foreach($tags_db as $tdb)
			$tags_db_array[$tdb->tag_name] = $tdb->tag_id;
			
		//delete exsisting post_tag in database
		$this->Ms_Tags_Model->delete_post_tag($id_post);
	
		//insert tags into database
		foreach($tags as $tag)
		{
			if(isset($tags_db_array[$tag]))
				$id = $tags_db_array[$tag];
			else							
				$id = $this->Ms_Tags_Model->add(array('tag_url' => y_urlf($tag), 'tag_name' => $tag));
			
			$this->Ms_Tags_Model->add_post_tag(array('pt_id_post' => $id_post, 'pt_id_tag' => $id));
		}
		
		//recount tags
		$this->Ms_Tags_Model->recount_tags();
	}
	
	private function cats_handler($id_post, $cats)
	{
		$items = array();
		foreach($cats as $cat)
			$items[] = array( 'pc_id_post' 	=> $id_post,
							  'pc_id_cat'	=> $cat);
		
		$this->Ms_Category_Model->delete_post_cat($id_post);
		$this->Ms_Category_Model->add_post_cat($items);	
		
		//recount cats
		$this->Ms_Category_Model->recount_cats();
	}
	
	public function get_cat()
	{
		if(!$this->input->post('id')) return false;
		
		echo json_encode($this->Ms_Category_Model->getby(array('cat_type' => $this->input->post('id')))->result());
	}
	
	public function get_tags()
	{
		if(!$this->input->post('q')) return false;
		
		$tags = array();
		$tags_db = $this->Ms_Tags_Model->getbyq($this->input->post('q'))->result();
		
		if(!empty($tags_db))
			foreach($tags_db as $tag) 
				$tags[] = $tag->tag_name;
		
		echo json_encode($tags);
	}
	
	public function json_time_matrix($id)
	{
		if(!$this->input->is_ajax_request()) return false;
		
		$columns = array(
			array( 'db' => 'cat_name', 'dt' => 0 )
		);
		
		$dari = $this->dm->getbyid($id)->row();
		
		$this->datatables->set_cols($columns);
		$param	= $this->datatables->query();		
		$result = $this->dm->dtquery_tm($id)->result();
		$filter = $this->dm->dtfiltered_tm();
		$total	= $this->dm->dtcount_tm($id);
		$output = $this->datatables->output($total, $filter);
		
		foreach($result as $row)
		{
			$jam = floor($row->pt_waktu/3600);
			$menit = floor( ($row->pt_waktu%3600) / 60 );
			
			$rows = array (
				$dari->post_title_id,
				$row->post_title_id,
				$row->pt_hari,
				$row->pt_waktu,
				$jam.' Jam, '.$menit.' Menit'
			);
			
			$output['data'][] = $rows;
		}
		
		echo json_encode( $output );
	}
}

?>